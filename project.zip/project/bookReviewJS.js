

const parallax = document.getElementById("parallax");
window.addEventListener("scroll", function(){
    let offset = window.pageYOffset;
    parallax.style.backgroundPositionY= offset* 0.8 + "px";
})

/*const parallax2 = document.getElementById("parallax2");
window.addEventListener("scroll", function(){
    let offset2 = window.pageYOffset;
    parallax.style.backgroundPositionY= offset2* 1.2 + "px";
})*/

var vid= document.getElementById("bgvideo");
if(window.matchMedia('(prefers-reduced-motion)').matches){

    vid.removeAttribute("autoplay");
    vid.pause();
    pauseButton.innerHTML="Paused";
}
    
function vidFade() {
    vid.classList.add("stopfade");
}
    
vid.addEventListener('ended', function()
{
// only functional if "loop" is removed 
vid.pause();
// to capture IE10
vidFade();
});  




